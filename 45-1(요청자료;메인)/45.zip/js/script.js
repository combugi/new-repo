$(function(){

})//ready