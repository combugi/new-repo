<?php include "sub-header.php" ?>
공지사항 본문
<?php include "sub-footer.php" ?>