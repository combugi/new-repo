<?php include "sub-header.php" ?>
자유게시판 본문
<?php include "sub-footer.php" ?>