<ul>
  <li class="menu1">
    <a href="page1-1.php">company</a>
    <ul>
      <li><a href="page1-1.php" class="menu1-1 icon-font">인사말</a></li>
      <li><a href="page1-2.php" class="menu1-2 icon-font">오시는길</a></li>
    </ul>
  </li>
  <li class="menu2">
    <a href="page2-1.php">business</a>
    <ul>
      <li><a href="page2-1.php" class="menu2-1 icon-font">사업소개</a></li>
      <li><a href="page2-2.php" class="menu2-2 icon-font">사업분야</a></li>
    </ul>
  </li>
  <li class="menu3">
    <a href="page3-1.php">gallery</a>
    <ul>
      <li><a href="page3-1.php" class="menu3-1 icon-font">갤러리</a></li>
    </ul>
  </li>
  <li class="menu4">
    <a href="page4-1.php">contact</a>
    <ul>
      <li><a href="page4-1.php" class="menu4-1 icon-font">온라인문의</a></li>
    </ul>
  </li>
  <li class="menu5">
    <a href="page5-1.php">comunity</a>
    <ul>
      <li><a href="page5-1.php" class="menu5-1 icon-font">공지사항</a></li>
      <li><a href="page5-2.php" class="menu5-2 icon-font">질문과답변</a></li>
      <li><a href="page5-3.php" class="menu5-3 icon-font">자유게시판</a></li>
    </ul>
  </li>
  <li class="sns-menu">
    <a class="dummy-link" href="#">sns</a>
    <ul>
      <li><a class="dummy-link" href="#"><i class="fa-brands fa-facebook-square"></i></a></li>
      <li><a class="dummy-link" href="#"><i class="fa-brands fa-twitter-square"></i></a></li>
      <li><a class="dummy-link" href="#"><i class="fa-brands fa-instagram-square"></i></a></li>
      <li><a class="dummy-link" href="#"><i class="fa-brands fa-telegram"></i></a></li>
    </ul>
  </li>
</ul>