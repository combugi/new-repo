<?php include "header.php" ?>
  첫페이지 본문
<?php include "footer.php" ?>