<nav class="sitemap">
  <?php include "menu.php" ?>
</nav>
<footer>
  <address>
    <i>주소 : 부산광역시 해운대구 좌동 273-10</i>
    <i>상호 : 디자인선사인</i>
    <i>사업자등록번호 : 123-456-7890</i>
    <i>Tel : 070-7155-1979</i>
    <i>Fax : 02-2139-1142 </i>
    <i>E-mail : gijung23@nate.com</i>
  </address>
  <p>
    Copyright &copy; Sunsine.com All Rights Reserved.
  </p>
</footer>
<button class="top-btn"> 
  <i class="fa-solid fa-arrow-turn-up"></i>
</button>
</body>
</html>