<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="./css/reset.css">
  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/header.css">
  <script src="https://kit.fontawesome.com/1db539ee0d.js" crossorigin="anonymous"></script>
  <script src="http://code.jquery.com/jquery-latest.js" type="text/javascript"></script>

  <title>선사인 독자개발</title>
</head>

<body>
  <header>
    <div class="list-container">
      <ul>
        <li><a href="">처음으로</a></li>
        <li><a href="#">로그인</a></li>
        <li><a href="#">회원가입</a></li>
        <li><a href="#">즐겨찾기</a></li>
      </ul>
    </div>
    <ul>
      <a href=""><img src="./img/icons/logo.png" alt=""></a>
      <li>
        <a href="">회사소개</a>
        <ul>
          <li>
            <a href="">인사말</a>
          </li>
          <li>
            <a href="">오시는길</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="">사업분야</a>
        <ul>
          <li>
            <a href="">사업소개</a>
          </li>
          <li>
            <a href="">사업분야</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="">갤러리</a>
        <ul>
          <li>
            <a href="">갤러리</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="">온라인문의</a>
        <ul>
          <li>
            <a href="">온라인문의</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="">커뮤니티</a>
        <ul>
          <li>
            <a href="">공지사항</a>
          </li>
          <li>
            <a href="">질문과답변</a>
          </li>
          <li>
            <a href="">자유게시판</a>
          </li><!-- 2dep li -->
        </ul><!-- 2dep ul -->
      </li><!-- 1dep li -->
    </ul><!-- 1dep ul -->
    <button class="bars-btn">
      <span>
      <i class="fa-solid fa-bars"></i>
      </span>
  
     
    </button>
    <button class="tel-btn">
      <span>
            <i class="fa-solid fa-phone"></i>
      </span>
  
      
    </button>
  </header>